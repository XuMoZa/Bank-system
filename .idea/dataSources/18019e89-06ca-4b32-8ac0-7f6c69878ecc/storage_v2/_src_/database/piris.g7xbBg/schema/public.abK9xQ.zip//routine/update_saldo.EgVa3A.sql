create function update_saldo() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.state = 'Active' THEN
        NEW.saldo := NEW.debet - NEW.credit;
    ELSEIF NEW.state = 'Passive' THEN
        NEW.saldo := NEW.credit - NEW.debet;
    END IF;
    RETURN NEW;
END;
$$;

alter function update_saldo() owner to "Manishka";

